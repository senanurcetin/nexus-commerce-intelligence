# NEXUS Olist Research

Source: Brazilian E-Commerce Public Dataset by Olist, https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce

Olist-derived aggregates and this data-containing report: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). NEXUS prepared the analytical transformations; this is a non-commercial portfolio study, not endorsed by Olist. Source and calculation fingerprints accompany this package.

Purchase window: January 2017 through July 2018. As-of customer policies include earlier observed history. Item GMV is in source price units, excludes freight and is not net revenue or profit. Late-delivery contrasts use post-delivery review answers and are selected-sample associations, not causal effects. Repeat timing uses distinct purchase days with administrative censoring; pointwise intervals do not validate independent censoring. Product concentration is within this portfolio, not a market-wide competition measure. Operations compares January-July in both years, without a review-response filter. Rate/mix contributions are descriptive, and late-delivered GMV is not revenue lost. The fourth bundled study, REVIEW_SELECTION.md, analyzes unavailable ratings with a different mature cohort; its sharp ranges are not confidence intervals or causal effects. It is a companion report, not a native BI page. Confidence cards refer to the full sample and do not follow monthly selections.

Desktop rendering, refresh and DAX execution are unverified. Open the entire PBIP folder in a compatible Power BI Desktop installation.
